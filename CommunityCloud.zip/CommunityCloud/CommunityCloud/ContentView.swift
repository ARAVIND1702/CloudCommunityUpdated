//
//  ContentView.swift
//  CommunityCloud
//
//  Created by GGS-BKS on 14/08/23.
//

import SwiftUI
import CoreData

struct ContentView: View {
    
    
    var body: some View {
       LoginView()
       
    }
    
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
