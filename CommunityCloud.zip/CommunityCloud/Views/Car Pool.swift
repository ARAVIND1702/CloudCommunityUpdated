//
//  Car Pool.swift
//  CommunityCloud
//
//  Created by GGS-BKS on 16/08/23.
//

import SwiftUI

struct Car_Pool: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct Car_Pool_Previews: PreviewProvider {
    static var previews: some View {
        Car_Pool()
    }
}
